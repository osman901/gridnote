class AppPaths {
  static const String logo = 'assets/logo.png';
// SumÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ otros paths globales si tenÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s, ej: imÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡genes o plantillas
}
