// lib/screens/note_sheet_pluto_screen.dart
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:pluto_grid/pluto_grid.dart';

import '../models/free_sheet.dart';
import '../services/free_sheet_service.dart';
import '../services/attachments_service.dart';
import '../services/diagnostics_service.dart';
import '../theme/gridnote_theme.dart';

class NoteSheetPlutoScreen extends StatefulWidget {
  const NoteSheetPlutoScreen({super.key, this.id, required this.theme});
  final String? id;
  final GridnoteThemeController theme;

  @override
  State<NoteSheetPlutoScreen> createState() => _NoteSheetPlutoScreenState();
}

class _NoteSheetPlutoScreenState extends State<NoteSheetPlutoScreen> {
  FreeSheetData? _data;
  bool _loading = true;

  Timer? _debounce;
  void _scheduleSave() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () async {
      final d = _data;
      if (d != null) {
        await FreeSheetService.instance.save(d);
      }
    });
  }

  final List<PlutoColumn> _columns = [];
  final List<PlutoRow> _rows = [];
  PlutoGridStateManager? _manager;

  // Paleta
  static const Color _black = Color(0xFF000000);
  static const Color _black2 = Color(0xFF0E0E10);
  static const Color _white = Colors.white;
  static const Color _whiteDim = Colors.white70;
  static const Color _brown = Color(0xFF5D4037);
  static const Color _paperWarm = Color(0xFFEDE5D9);
  static const Color _ink = Color(0xFF141414);

  // Pintado
  final Set<int> _paintCols = {};
  final Set<int> _paintRows = {};
  final Set<String> _paintCells = {};
  String _k(int r, int c) => '$r:$c';
  bool _isPainted(int r, int c) =>
      _paintCols.contains(c) || (r > 0 && _paintRows.contains(r)) || _paintCells.contains(_k(r, c));
  void _toggleCell(int r, int c) => setState(() {
    final key = _k(r, c);
    final removed = _paintCells.remove(key);
    if (!removed) {
      _paintCells.add(key);
    }
  });
  void _toggleCol(int c) => setState(() {
    final removed = _paintCols.remove(c);
    if (!removed) {
      _paintCols.add(c);
    }
  });
  void _toggleRow(int r) => setState(() {
    if (r > 0) {
      final removed = _paintRows.remove(r);
      if (!removed) {
        _paintRows.add(r);
      }
    }
  });

  GridnoteTheme get t => widget.theme.theme;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    FreeSheetData? d;
    if (widget.id == null) {
      d = await FreeSheetService.instance.create(name: 'Bloc de notas');
      await DiagnosticsService.instance.log('notes_pluto', 'creada ${d.id}');
    } else {
      d = await FreeSheetService.instance.get(widget.id!) ??
          await FreeSheetService.instance.create(name: 'Bloc de notas');
    }

    d.ensureWidth(d.headers.length);
    d.ensureHeight(10);
    _ensureHeaderRow(d);

    _buildGridFromData(d);
    setState(() {
      _data = d;
      _loading = false;
    });
  }

  void _ensureHeaderRow(FreeSheetData d) {
    if (d.rows.isEmpty) {
      d.rows.add(List.filled(d.headers.length, '', growable: true));
    }
    if (d.rows[0].length < d.headers.length) {
      d.rows[0].addAll(List.filled(d.headers.length - d.rows[0].length, '', growable: true));
    }
    for (int c = 0; c < d.headers.length; c++) {
      if ((d.rows[0][c]).toString().trim().isEmpty) {
        d.rows[0][c] = d.headers[c];
      }
    }
  }

  void _syncDataFromGrid() {
    final sm = _manager;
    final d = _data;
    if (sm == null || d == null) return;

    final nonAction = sm.columns.where((c) => c.field != '_actions').toList(growable: false);
    final newRows = sm.rows
        .map((r) => List<String>.generate(nonAction.length, (i) => r.cells['c$i']?.value?.toString() ?? '',
        growable: true))
        .toList();

    d.rows
      ..clear()
      ..addAll(newRows);
    if (d.rows.isNotEmpty) {
      d.headers
        ..clear()
        ..addAll(List<String>.generate(nonAction.length, (i) => d.rows[0][i]));
    }
    _scheduleSave();
  }

  void _buildGridFromData(FreeSheetData d) {
    _columns.clear();

    for (int i = 0; i < d.headers.length; i++) {
      final headerName = d.headers[i];
      _columns.add(
        PlutoColumn(
          title: '',
          field: 'c$i',
          type: PlutoColumnType.text(),
          enableContextMenu: false,
          enableSorting: false,
          enableColumnDrag: true,
          renderer: (ctx) {
            final r = ctx.rowIdx, c = i;
            final isCurrent = ctx.cell == ctx.stateManager.currentCell;
            final isEditing = isCurrent && ctx.stateManager.isEditing;

            // Solo titulo/edición/pintado colorean; resto transparente
            Color? bg;
            if (r == 0) {
              bg = _black;
            } else if (isEditing) {
              bg = _paperWarm;
            } else if (_isPainted(r, c)) {
              bg = _brown;
            }

            final value = (ctx.cell.value ?? '').toString();
            final lname = headerName.toLowerCase();

            Widget child;
            if (lname.contains('foto') && value.isNotEmpty) {
              final path = value.startsWith('file://') ? Uri.parse(value).toFilePath() : value;
              child = ClipRRect(
                borderRadius: BorderRadius.circular(isEditing || r == 0 ? 10 : 0),
                child: Image.file(
                  File(path),
                  height: double.infinity,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _cellText(value, r, isEditing),
                ),
              );
            } else if (lname.contains('ubicación') && value.startsWith('geo:')) {
              child = InkWell(
                onTap: () => AttachmentsService.instance.openGeo(value),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.place_outlined, size: 18, color: _white),
                    const SizedBox(width: 6),
                    Flexible(child: _cellText(value.replaceFirst('geo:', ''), r, isEditing)),
                  ],
                ),
              );
            } else if (lname.contains('firma') && value.isNotEmpty) {
              final path = value.startsWith('file://') ? Uri.parse(value).toFilePath() : value;
              child = ClipRRect(
                borderRadius: BorderRadius.circular(isEditing || r == 0 ? 10 : 0),
                child: Image.file(File(path), fit: BoxFit.contain),
              );
            } else {
              child = _cellText(value, r, isEditing);
            }

            return GestureDetector(
              onLongPress: () => _toggleCell(r, c),
              onDoubleTap: () => _toggleCol(c),
              onSecondaryTap: () => _toggleRow(r),
              child: Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: bg,
                  borderRadius: BorderRadius.circular((r == 0 || isEditing || _isPainted(r, c)) ? 10 : 0),
                ),
                child: child,
              ),
            );
          },
        ),
      );
    }

    // Acciones
    _columns.add(
      PlutoColumn(
        title: 'Adjuntos',
        field: '_actions',
        type: PlutoColumnType.text(),
        enableEditingMode: false,
        enableContextMenu: false,
        frozen: PlutoColumnFrozen.end,
        width: 96,
        titleTextAlign: PlutoColumnTextAlign.center,
        renderer: (ctx) => Align(
          alignment: Alignment.centerRight,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _actionIcon(icon: Icons.photo_outlined, onTap: () => _choosePhoto(ctx.rowIdx)),
              _actionIcon(icon: Icons.location_on_outlined, onTap: () => _attachLocation(ctx.rowIdx)),
              _actionIcon(icon: Icons.edit_outlined, onTap: () => _attachSignature(ctx.rowIdx)),
            ],
          ),
        ),
      ),
    );

    _rows
      ..clear()
      ..addAll(List.generate(d.rows.length, (r) {
        if (d.rows[r].length < d.headers.length) {
          d.rows[r].addAll(List.filled(d.headers.length - d.rows[r].length, '', growable: true));
        }
        final map = <String, PlutoCell>{};
        for (int c = 0; c < d.headers.length; c++) {
          map['c$c'] = PlutoCell(value: d.rows[r][c]);
        }
        map['_actions'] = PlutoCell(value: '');
        return PlutoRow(cells: map);
      }));
  }

  Widget _cellText(String text, int rowIndex, bool isEditing) => Text(
    text,
    overflow: TextOverflow.ellipsis,
    style: TextStyle(
      color: isEditing ? _ink : _white,
      fontWeight: rowIndex == 0 ? FontWeight.w700 : FontWeight.w400,
      fontSize: 15,
      height: 1.2,
    ),
  );

  // ignore: unused_element
  Future<void> _addColumn() async {
    final d = _data!;
    final idx = d.headers.length;
    d.headers.add('');
    for (final row in d.rows) {
      row.add('');
    }

    final insertAt = (_manager?.columns.length ?? 1) - 1;
    final col = PlutoColumn(
      title: '',
      field: 'c$idx',
      type: PlutoColumnType.text(),
      enableContextMenu: false,
      enableSorting: false,
      enableColumnDrag: true,
      renderer: (ctx) {
        final r = ctx.rowIdx;
        final isCurrent = ctx.cell == ctx.stateManager.currentCell;
        final isEditing = isCurrent && ctx.stateManager.isEditing;
        final bg = r == 0 ? _black : (isEditing ? _paperWarm : null);
        return Container(
          alignment: Alignment.centerLeft,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular((r == 0 || isEditing) ? 10 : 0)),
          child: _cellText('${ctx.cell.value ?? ''}', r, isEditing),
        );
      },
    );

    _manager?.insertColumns(insertAt.clamp(0, insertAt), [col]);
    for (final r in _manager?.rows ?? const []) {
      r.cells['c$idx'] = PlutoCell(value: '');
    }
    _scheduleSave();
    setState(() {});
  }

  // ignore: unused_element
  Future<void> _removeSelectedColumn() async {
    final sm = _manager;
    final d = _data;
    if (sm == null || d == null) return;

    final col = sm.currentColumn;
    if (col == null || col.field == '_actions') return;

    final idx = int.tryParse(col.field.replaceFirst('c', '')) ?? -1;
    if (idx < 0 || idx >= d.headers.length) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar columna'),
        content: const Text('Esto no se puede deshacer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok != true) return;

    d.headers.removeAt(idx);
    for (final row in d.rows) {
      if (row.length > idx) {
        row.removeAt(idx);
      }
    }
    sm.removeColumns([col]);

    final nonAction = sm.columns.where((c) => c.field != '_actions').toList();
    for (var i = 0; i < nonAction.length; i++) {
      final c = nonAction[i];
      if (c.field != 'c$i') {
        final old = c.field;
        c.field = 'c$i';
        for (final r in sm.rows) {
          r.cells['c$i'] = r.cells[old] ?? PlutoCell(value: '');
          r.cells.remove(old);
        }
      }
    }
    _scheduleSave();
    setState(() {});
  }

  Future<void> _addRow() async {
    final d = _data!;
    final width = d.headers.length;
    d.rows.add(List.filled(width, '', growable: true));
    final idx = d.rows.length - 1;

    final cells = <String, PlutoCell>{};
    for (int c = 0; c < width; c++) {
      cells['c$c'] = PlutoCell(value: '');
    }
    cells['_actions'] = PlutoCell(value: '');
    _manager?.appendRows([PlutoRow(cells: cells)]);
    _scheduleSave();
    setState(() {});
    _manager?.setCurrentCell(cells['c0'], idx);
    _manager?.moveScrollByRow(PlutoMoveDirection.down, 1000);
  }

  // ignore: unused_element
  Future<void> _removeSelectedRow() async {
    final sm = _manager;
    final d = _data;
    if (sm == null || d == null) return;
    final row = sm.currentRow;
    if (row == null) return;

    final idx = sm.rows.indexOf(row);
    if (idx <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('La fila de títulos no puede eliminarse')));
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar fila'),
        content: const Text('Esto no se puede deshacer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok != true) return;

    d.rows.removeAt(idx);
    sm.removeRows([row]);
    _scheduleSave();
    setState(() {});
  }

  // ---------- Adjuntos ----------
  Future<void> _choosePhoto(int rowIndex) async {
    if (rowIndex == 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Los adjuntos se aplican a filas de datos')));
      return;
    }
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Sacar foto'),
              onTap: () => Navigator.pop(ctx, 'Sacar foto'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Elegir de galería'),
              onTap: () => Navigator.pop(ctx, 'Elegir de galería'),
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
    String? path;
    if (selected == 'Sacar foto') {
      path = await AttachmentsService.instance.pickFromCamera();
    } else if (selected == 'Elegir de galería') {
      path = await AttachmentsService.instance.pickFromGallery();
    } else {
      return;
    }
    if (path == null || path.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Foto cancelada')));
      return;
    }
    _writeAttachment(rowIndex, 'Foto', path);
  }

  Future<void> _attachLocation(int rowIndex) async {
    if (rowIndex == 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Los adjuntos se aplican a filas de datos')));
      return;
    }
    final value = await AttachmentsService.instance.getCurrentLocation();
    if (value == null || value.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ubicación cancelada')));
      return;
    }
    _writeAttachment(rowIndex, 'Ubicación', value);
  }

  Future<void> _attachSignature(int rowIndex) async {
    if (rowIndex == 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Los adjuntos se aplican a filas de datos')));
      return;
    }
    final value = await AttachmentsService.instance.addSignature(context);
    if (value == null || value.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Firma cancelada')));
      return;
    }
    _writeAttachment(rowIndex, 'Firma', value);
  }

  void _writeAttachment(int rowIndex, String title, String value) {
    final d = _data!;
    final colIdx = _ensureColumn(title);
    d.rows[rowIndex][colIdx] = value;
    final cell = _manager?.rows[rowIndex].cells['c$colIdx'];
    if (cell != null) {
      cell.value = value;
    }
    _scheduleSave();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title adjuntada')));
  }

  int _ensureColumn(String title) {
    final d = _data!;
    var idx = d.headers.indexWhere((h) => h.toLowerCase() == title.toLowerCase());
    if (idx >= 0) return idx;

    d.headers.add(title);
    for (final row in d.rows) {
      row.add('');
    }
    idx = d.headers.length - 1;

    final insertAt = (_manager?.columns.length ?? 1) - 1;
    final col = PlutoColumn(
      title: '',
      field: 'c$idx',
      type: PlutoColumnType.text(),
      enableContextMenu: false,
      enableSorting: false,
      enableColumnDrag: true,
      renderer: (ctx) {
        final r = ctx.rowIdx;
        final isCurrent = ctx.cell == ctx.stateManager.currentCell;
        final isEditing = isCurrent && ctx.stateManager.isEditing;
        final bg = r == 0 ? _black : (isEditing ? _paperWarm : null);
        return Container(
          alignment: Alignment.centerLeft,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular((r == 0 || isEditing) ? 10 : 0)),
          child: _cellText('${ctx.cell.value ?? ''}', r, isEditing),
        );
      },
    );
    _manager?.insertColumns(insertAt.clamp(0, insertAt), [col]);
    for (final r in _manager?.rows ?? const []) {
      r.cells['c$idx'] = PlutoCell(value: '');
    }
    _scheduleSave();
    setState(() {});
    return idx;
  }

  Widget _actionIcon({required IconData icon, required VoidCallback onTap}) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 2),
    child: InkWell(
      borderRadius: BorderRadius.circular(6),
      onTap: onTap,
      child: SizedBox(
        width: 28,
        height: 28,
        child: Icon(icon, size: 18, color: _white),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    if (_loading || _data == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final d = _data!;
    final keyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;

    return Scaffold(
      backgroundColor: _black,
      appBar: AppBar(
        backgroundColor: _black,
        title: Text(d.name, overflow: TextOverflow.ellipsis),
        actions: const [
          // usa const para performance
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: PlutoGrid(
          columns: _columns,
          rows: _rows,
          onLoaded: (evt) {
            _manager = evt.stateManager
              ..setSelectingMode(PlutoGridSelectingMode.cell)
              ..setAutoEditing(true)
              ..setConfiguration(
                PlutoGridConfiguration.dark().copyWith(
                  style: PlutoGridConfiguration.dark().style.copyWith(
                    gridBackgroundColor: _black,
                    rowColor: _black2,
                    gridBorderColor: _white.withValues(alpha: .14),
                    activatedBorderColor: _white,
                    activatedColor: _black2,
                    columnHeight: 34,
                    rowHeight: 50,
                    columnTextStyle:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _whiteDim),
                    cellTextStyle: const TextStyle(fontSize: 15, height: 1.2, color: _white),
                  ),
                ),
              );
          },
          onChanged: (evt) {
            if (evt.column.field == '_actions') return;
            final r = evt.rowIdx;
            final c = int.tryParse(evt.column.field.replaceFirst('c', '')) ?? -1;
            if (r < 0 || c < 0) return;

            final d = _data!;
            if (r >= d.rows.length) {
              d.rows.addAll(List.generate(r - d.rows.length + 1, (_) => List.filled(d.headers.length, '', growable: true)));
            }
            if (d.rows[r].length < d.headers.length) {
              d.rows[r].addAll(List.filled(d.headers.length - d.rows[r].length, '', growable: true));
            }

            d.rows[r][c] = evt.value?.toString() ?? '';
            if (r == 0 && c >= 0 && c < d.headers.length) {
              d.headers[c] = d.rows[0][c];
            }
            _scheduleSave();
          },
          onRowsMoved: (_) => _syncDataFromGrid(),
          onColumnsMoved: (_) => _syncDataFromGrid(),
        ),
      ),
      floatingActionButton: keyboardOpen
          ? null
          : FloatingActionButton.extended(
        onPressed: _addRow,
        icon: const Icon(Icons.add),
        label: const Text('Agregar fila'),
      ),
    );
  }
}
