// lib/screens/browse_sheets_screen.dart
import 'package:flutter/material.dart';
import '../theme/gridnote_theme.dart';
import 'settings_screen.dart';
import 'recover_sheets_screen.dart';

class BrowseSheetsScreen extends StatefulWidget {
  const BrowseSheetsScreen({super.key, required this.theme});
  final GridnoteThemeController theme;

  @override
  State<BrowseSheetsScreen> createState() => _BrowseSheetsScreenState();
}

class _BrowseSheetsScreenState extends State<BrowseSheetsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tab =
  TabController(length: 2, vsync: this, initialIndex: 0);

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.theme.theme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Explorar planillas'),
        actions: [
          IconButton(
            tooltip: 'Recargar',
            onPressed: () => setState(() {}),
            icon: const Icon(Icons.refresh),
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          tabs: const [
            Tab(text: 'Planillas'), // ← antes “Calendario”
            Tab(text: 'Opciones'),  // ← antes “Scroll”
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          // --------- Pestaña: PLANILLAS ----------
          _SheetsTab(theme: widget.theme),

          // --------- Pestaña: OPCIONES ----------
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              ListTile(
                leading: const Icon(Icons.settings_outlined),
                title: const Text('Ajustes'),
                subtitle: const Text('Guardar email por defecto, endpoint, etc.'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  );
                },
              ),
              const Divider(height: 24),
              ListTile(
                leading: const Icon(Icons.restore_from_trash_outlined),
                title: const Text('Recuperar planillas'),
                subtitle: const Text(
                  'Restaura planillas eliminadas recientemente.',
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          RecoverSheetsScreen(theme: widget.theme),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
              Text(
                'Nota: la recuperación depende de que el borrado sea “suave” '
                    '(se mueve a una papelera temporal). Si aún no lo tenemos en tu flujo, '
                    'lo agregamos enseguida.',
                style: TextStyle(color: t.text.withValues(alpha: .7), fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Contenido real de la lista de planillas.
/// (Usa tu lógica actual; aquí solo hay UI base y botones de filtro.)
class _SheetsTab extends StatelessWidget {
  const _SheetsTab({required this.theme});
  final GridnoteThemeController theme;

  @override
  Widget build(BuildContext context) {
    final t = theme.theme;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            OutlinedButton.icon(
              onPressed: () {
                // TODO: tu filtro por día
              },
              icon: const Icon(Icons.calendar_today_outlined),
              label: const Text('Filtrar por día'),
            ),
            OutlinedButton.icon(
              onPressed: () {
                // TODO: tu filtro por mes
              },
              icon: const Icon(Icons.calendar_month_outlined),
              label: const Text('Filtrar por mes'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        // TODO: sustituye este placeholder por tu ListView/Grid con SheetMeta
        Container(
          height: 160,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: t.divider),
          ),
          child: const Text('Aquí va tu lista de planillas'),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () {
            // TODO: crear nueva planilla
          },
          icon: const Icon(Icons.add),
          label: const Text('Nueva planilla'),
        ),
      ],
    );
  }
}
