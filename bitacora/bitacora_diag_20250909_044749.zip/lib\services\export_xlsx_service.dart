// lib/services/export_xlsx_service.dart
import 'dart:io';
import 'dart:math' as math;

import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' as sx;

import '../data/app_db.dart';
import '../data/sheets_dao.dart';

class ExportXlsxService {
  final SheetsDao dao;
  final AppDb db;
  ExportXlsxService(this.dao, this.db);

  static const _maxSheetNameLen = 31;
  static final _invalidSheetChars = RegExp(r'[:\\/?*\[\]]');

  String _sanitizeSheetName(String name) {
    final raw = (name.isEmpty ? 'Hoja' : name).replaceAll(_invalidSheetChars, '_');
    return raw.substring(0, math.min(raw.length, _maxSheetNameLen));
  }

  String _sanitizeFileName(String name) {
    final base = (name.isEmpty ? 'bitacora' : name).replaceAll(RegExp(r'[^\w\s\-.]'), '_').trim();
    return base.isEmpty ? 'bitacora' : base;
  }

  bool _isImg(String path) {
    final ext = p.extension(path).toLowerCase();
    return ext == '.png' || ext == '.jpg' || ext == '.jpeg';
  }

  Future<String> export(int sheetId) async {
    final sheet = await dao.getSheet(sheetId);
    final entries = await dao.getEntriesForSheet(sheetId);
    final counts = await dao.getAttachmentCountsMapForSheet(sheetId);

    final wb = sx.Workbook();
    final sh = wb.worksheets[0];

    sh.name = _sanitizeSheetName(sheet.name);

    final header = wb.styles.add('hdr')
      ..bold = true
      ..hAlign = sx.HAlignType.left;

    final headers = <String>['TÃƒÆ’Ã‚Â­tulo', 'Nota', 'UbicaciÃƒÆ’Ã‚Â³n', 'Adjuntos'];
    for (var c = 0; c < headers.length; c++) {
      sh.getRangeByIndex(1, c + 1).setText(headers[c]);
      sh.getRangeByIndex(1, c + 1).cellStyle = header;
      sh.setColumnWidthInPixels(c + 1, 180);
    }

    for (var i = 0; i < entries.length; i++) {
      final e = entries[i];
      final row = i + 2;

      sh.getRangeByIndex(row, 1).setText(e.title ?? '');
      sh.getRangeByIndex(row, 2).setText(e.note ?? '');

      if (e.lat != null && e.lng != null) {
        final q = '${e.lat},${e.lng}';
        final url = 'https://www.google.com/maps/search/?api=1&query=$q';
        final cell = sh.getRangeByIndex(row, 3);
        cell.setText(q);
        sh.hyperlinks.add(cell, sx.HyperlinkType.url, url);
      }

      sh.getRangeByIndex(row, 4).setNumber((counts[e.id] ?? 0).toDouble());
      sh.autoFitRow(row);
    }

    sh.autoFitRow(1);

    final bytes = wb.saveAsStream();
    wb.dispose();

    final dir = await getTemporaryDirectory();
    final fname = '${_sanitizeFileName(sheet.name)}_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final out = p.join(dir.path, fname);
    await File(out).writeAsBytes(bytes, flush: true);
    return out;
  }

  Future<void> exportAndOpen(int sheetId) async {
    final path = await export(sheetId);
    await OpenFilex.open(path);
  }
}
