// lib/services/notes_service.dart
import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;

/// Guarda y carga notas por planilla (sheetId) usando Hive.
/// Clave = "note_<sheetId>" ; Valor = JSON con { delta, updatedAt }
class NotesService {
  NotesService._();
  static final instance = NotesService._();

  static const String _boxName = 'notes_box';

  Future<Box> _openBox() async {
    if (!Hive.isBoxOpen(_boxName)) {
      return Hive.openBox(_boxName);
    }
    return Hive.box(_boxName);
  }

  Future<quill.Document> load(String sheetId) async {
    final box = await _openBox();
    final key = 'note_$sheetId';
    final raw = box.get(key);
    if (raw is String && raw.isNotEmpty) {
      try {
        final Map<String, dynamic> map = jsonDecode(raw);
        // v11: construir desde JSON (sin Delta)
        final ops = List<Map<String, dynamic>>.from(map['delta'] ?? const []);
        return quill.Document.fromJson(ops);
      } catch (_) {
        // si algo falla, devolvemos vacío
      }
    }
    return quill.Document();
  }

  Future<void> save(String sheetId, quill.Document doc) async {
    final box = await _openBox();
    final key = 'note_$sheetId';
    final payload = jsonEncode({
      'delta': doc.toDelta().toJson(), // no tipamos Delta; usamos dynamic
      'updatedAt': DateTime.now().toIso8601String(),
    });
    await box.put(key, payload);
  }

  Future<void> clear(String sheetId) async {
    final box = await _openBox();
    await box.delete('note_$sheetId');
  }
}
