// lib/models/share_option.dart
enum ShareOption {
  sendVisible,
  sendAll,
}
