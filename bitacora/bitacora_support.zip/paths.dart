﻿class AppPaths {
  static const String logo = 'assets/logo.png';
// SumÃ¡ otros paths globales si tenÃ©s, ej: imÃ¡genes o plantillas
}
