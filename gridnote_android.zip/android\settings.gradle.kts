// android/settings.gradle.kts
import java.util.Properties

pluginManagement {
    // Lee flutter.sdk desde local.properties
    val props = Properties()
    val lp = file("local.properties")
    if (lp.exists()) lp.inputStream().use { props.load(it) }
    val flutterSdkPath = props.getProperty("flutter.sdk")
        ?: throw GradleException("flutter.sdk not set in local.properties")

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
}

include(":app")
