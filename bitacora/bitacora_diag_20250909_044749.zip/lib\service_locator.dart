// lib/service_locator.dart
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart' as dotenv;

import 'services/xlsx_export_service.dart';
import 'services/csv_export_service.dart';
import 'services/pdf_export_service.dart';
import 'services/ocr_table_import_service.dart';
import 'services/suggest_service.dart';

final getIt = GetIt.instance;

/// Lista local de correos permitidos (útil para pruebas/offline).
const _allowedEmailsLocal = <String>[];

Future<void> setupServiceLocator() async {
  // Core async singletons
  final sp = await SharedPreferences.getInstance();
  getIt.registerSingleton<SharedPreferences>(sp);

  // ----- Allowed emails (sin Firebase Remote Config) -----
  // 1) Intentar leer de .env (ALLOWED_EMAILS)
  //    - Puede ser JSON ["a@x.com","b@y.com"] o CSV "a@x.com,b@y.com"
  // 2) Fallback: SharedPreferences key 'allowed_emails' (mismos formatos)
  // 3) Combinar con _allowedEmailsLocal
  List<String> allowedEmails = [];

  String? raw = dotenv.dotenv.isEveryDefined(['ALLOWED_EMAILS'])
      ? dotenv.dotenv.env['ALLOWED_EMAILS']
      : null;

  raw ??= sp.getString('allowed_emails');

  try {
    if (raw != null && raw.trim().isNotEmpty) {
      if (raw.trimLeft().startsWith('[')) {
        final List<dynamic> list = jsonDecode(raw);
        allowedEmails = list.cast<String>();
      } else {
        allowedEmails = raw
            .split(RegExp(r'[;,\s]+'))
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList();
      }
    }
  } catch (e) {
    debugPrint('No se pudo parsear ALLOWED_EMAILS: $e');
  }

  // Combinar con lista local
  allowedEmails.addAll(_allowedEmailsLocal);

  // Normalizar (lowercase + únicos)
  allowedEmails = allowedEmails.map((e) => e.toLowerCase()).toSet().toList();

  // Registrar como singleton
  getIt.registerSingleton<List<String>>(allowedEmails, instanceName: 'allowed_emails');

  // ----- Services -----
  getIt.registerLazySingleton<XlsxExportService>(() => XlsxExportService());
  getIt.registerLazySingleton<CsvExportService>(() => CsvExportService());
  getIt.registerLazySingleton<PdfExportService>(() => PdfExportService());
  getIt.registerLazySingleton<OcrTableImportService>(() => OcrTableImportService());
  getIt.registerLazySingleton<SuggestService>(() => SuggestService());
}
