import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'theme/gridnote_theme.dart'; // GridnoteThemeController extends ChangeNotifier
import 'data/app_db.dart';
import 'services/sheets_repository_drift.dart';

// ===== Tema =====
final themeControllerProvider =
ChangeNotifierProvider<GridnoteThemeController>(
      (ref) => GridnoteThemeController(),
);

// ===== DB singleton =====
final dbProvider = Provider<AppDb>((ref) => AppDb());

// ===== Repo (Drift) =====
final sheetsRepoProvider = Provider<SheetsRepository>(
      (ref) => SheetsRepository(ref.watch(dbProvider)),
);

// ===== Stream de planillas ordenadas =====
final sheetsProvider = StreamProvider<List<SheetRow>>((ref) {
  final repo = ref.watch(sheetsRepoProvider);
  return repo.watchSheetsSorted();
});

// ===== Stream de entradas por planilla =====
final entriesProvider =
StreamProvider.family<List<EntryRow>, int>((ref, sheetId) {
  final repo = ref.watch(sheetsRepoProvider);
  return repo.watchEntries(sheetId);
});
