import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'models.dart';
import 'repository.dart';
import 'glass.dart';

class SheetPage extends StatefulWidget {
  final Sheet sheet;
  const SheetPage({super.key, required this.sheet});

  @override
  State<SheetPage> createState() => _SheetPageState();
}

class _SheetPageState extends State<SheetPage> {
  final repo = Repo();
  final _picker = ImagePicker();
  List<Entry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await repo.entriesBySheet(widget.sheet.id!);
    setState(() {
      _entries = list;
      _loading = false;
    });
  }

  Future<void> _addRow() async {
    final e = await repo.addEmptyEntry(widget.sheet.id!);
    setState(() => _entries.insert(0, e));
    _savedSnack();
  }

  void _savedSnack() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Guardado en el dispositivo ✅'), duration: Duration(milliseconds: 900)),
    );
  }

  Future<void> _pickPhoto(Entry e) async {
    final x = await _picker.pickImage(source: ImageSource.camera); // camera; cambia a gallery si querés
    if (x == null) return;
    final file = File(x.path);
    final path = await repo.persistImage(file, sheetId: e.sheetId, entryId: e.id!);
    final updated = e.copyWith(photoPath: path);
    await repo.updateEntry(updated);
    final idx = _entries.indexWhere((r) => r.id == e.id);
    setState(() => _entries[idx] = updated);
    _savedSnack();
  }

  Future<void> _pickLocation(Entry e) async {
    final ok = await _ensureLocationPerms();
    if (!ok) return;
    final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    final updated = e.copyWith(lat: pos.latitude, lon: pos.longitude);
    await repo.updateEntry(updated);
    final idx = _entries.indexWhere((r) => r.id == e.id);
    setState(() => _entries[idx] = updated);
    _savedSnack();
  }

  Future<bool> _ensureLocationPerms() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return false;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.deniedForever) return false;
    return permission == LocationPermission.always || permission == LocationPermission.whileInUse;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0e0f12),
      appBar: AppBar(
        title: Text(widget.sheet.name, overflow: TextOverflow.ellipsis),
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        actions: [
          IconButton(
            tooltip: 'Renombrar',
            onPressed: () async {
              final c = TextEditingController(text: widget.sheet.name);
              final name = await showDialog<String>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Nombre de la planilla'),
                  content: TextField(controller: c, autofocus: true),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
                    FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Guardar')),
                  ],
                ),
              );
              if (name != null && name.isNotEmpty) {
                await repo.renameSheet(widget.sheet.id!, name);
                if (!mounted) return;
                setState(() {});
                _savedSnack();
              }
            },
            icon: const Icon(Icons.edit_note_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addRow,
        label: const Text('Agregar fila'),
        icon: const Icon(Icons.add),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Glass(
              child: Row(
                children: [
                  const Icon(Icons.info_outline_rounded),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Total filas: ${_entries.length}')),
                  FilledButton.tonalIcon(
                    onPressed: _addRow,
                    icon: const Icon(Icons.add),
                    label: const Text('Nueva fila'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: _entries.isEmpty
                  ? const Center(child: Text('Sin filas aún', style: TextStyle(color: Colors.white70)))
                  : ListView.separated(
                itemCount: _entries.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) => _EntryTile(
                  e: _entries[i],
                  onPhoto: _pickPhoto,
                  onLocation: _pickLocation,
                  onChanged: (updated) async {
                    await repo.updateEntry(updated);
                    final idx = _entries.indexWhere((r) => r.id == updated.id);
                    setState(() => _entries[idx] = updated);
                    _savedSnack();
                  },
                  onDelete: (id) async {
                    await repo.deleteEntry(id);
                    setState(() => _entries.removeWhere((x) => x.id == id));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EntryTile extends StatefulWidget {
  final Entry e;
  final Future<void> Function(Entry) onPhoto;
  final Future<void> Function(Entry) onLocation;
  final Future<void> Function(Entry) onChanged;
  final Future<void> Function(int id) onDelete;
  const _EntryTile({
    required this.e, required this.onPhoto, required this.onLocation,
    required this.onChanged, required this.onDelete,
  });

  @override
  State<_EntryTile> createState() => _EntryTileState();
}

class _EntryTileState extends State<_EntryTile> {
  late TextEditingController ctrl;

  @override
  void initState() {
    super.initState();
    ctrl = TextEditingController(text: widget.e.note ?? '');
  }

  @override
  void didUpdateWidget(covariant _EntryTile oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.e.note != widget.e.note) ctrl.text = widget.e.note ?? '';
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.e;
    return Glass(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: TextField(
                controller: ctrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Observaciones / datos',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: InputBorder.none,
                ),
                minLines: 1, maxLines: 5,
                onSubmitted: (_) => widget.onChanged(e.copyWith(note: ctrl.text.trim())),
                onEditingComplete: () => widget.onChanged(e.copyWith(note: ctrl.text.trim())),
              ),
            ),
            IconButton(
              tooltip: 'Eliminar fila',
              onPressed: () => widget.onDelete(e.id!),
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            ),
          ]),
          const SizedBox(height: 6),
          Row(
            children: [
              // Foto
              InkWell(
                onTap: () => widget.onPhoto(e),
                child: Container(
                  width: 84, height: 84,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.white.withValues(alpha: .06),
                    border: Border.all(color: Colors.white.withValues(alpha: .22)),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: e.photoPath == null
                      ? const Center(child: Icon(Icons.photo_camera_outlined))
                      : Image.file(File(e.photoPath!), fit: BoxFit.cover),
                ),
              ),
              const SizedBox(width: 12),
              // Ubicación
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FilledButton.icon(
                      onPressed: () => widget.onLocation(e),
                      icon: const Icon(Icons.my_location_rounded),
                      label: const Text('Guardar ubicación'),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      e.lat != null && e.lon != null
                          ? 'Lat: ${e.lat!.toStringAsFixed(6)}  Lon: ${e.lon!.toStringAsFixed(6)}'
                          : 'Sin ubicación',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
