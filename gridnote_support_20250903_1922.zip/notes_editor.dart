// lib/widgets/notes_editor.dart
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../services/dictation_service.dart';
import '../services/notes_service.dart';

/// Abre el bloc de notas como bottom sheet (desde cualquier pantalla).
Future<void> showNotesBottomSheet(
    BuildContext context, {
      required String sheetId,
      required Color accent,
    }) async {
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _NotesEditorSheet(sheetId: sheetId, accent: accent),
  );
}

class _NotesEditorSheet extends StatefulWidget {
  const _NotesEditorSheet({required this.sheetId, required this.accent});
  final String sheetId;
  final Color accent;

  @override
  State<_NotesEditorSheet> createState() => _NotesEditorSheetState();
}

class _NotesEditorSheetState extends State<_NotesEditorSheet> {
  late final quill.QuillController _controller;
  StreamSubscription? _docSub;
  StreamSubscription? _dictSub;

  bool _loading = true;
  bool _saving = false;

  // Dictado
  final _dict = DictationService.instance;
  double _level = 0; // 0..1
  bool _listening = false;

  // Autosave debounce
  DateTime _lastEdit = DateTime.now();

  @override
  void initState() {
    super.initState();
    _boot();
  }

  @override
  void dispose() {
    _docSub?.cancel();
    _dictSub?.cancel();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _boot() async {
    final doc = await NotesService.instance.load(widget.sheetId);
    _controller = quill.QuillController(
      document: doc,
      selection: const TextSelection.collapsed(offset: 0),
    );

    _docSub = _controller.document.changes.listen((_) => _scheduleSave());
    _dictSub = _dict.states.listen((s) {
      if (!mounted) return;
      setState(() {
        _level = s.level;
        _listening = s.listening;
      });
    });

    if (mounted) setState(() => _loading = false);
  }

  void _scheduleSave() {
    _lastEdit = DateTime.now();
    if (_saving) return;
    _saving = true;
    Future.delayed(const Duration(milliseconds: 600), () async {
      if (DateTime.now().difference(_lastEdit).inMilliseconds < 500) {
        _saving = false;
        _scheduleSave();
        return;
      }
      try {
        await NotesService.instance.save(widget.sheetId, _controller.document);
      } finally {
        _saving = false;
      }
    });
  }

  Future<void> _toggleMic() async {
    if (_listening) {
      await _dict.stop();
      return;
    }
    final ok = await _dict.init(localeId: 'es_AR');
    if (!ok) return;
    await _dict.start(
      localeId: 'es_AR',
      onChunk: (text) {
        final sel = _controller.selection;
        final insertAt =
        (sel.baseOffset < 0) ? _controller.document.length : sel.baseOffset;
        final prefixSpace = insertAt > 0 ? ' ' : '';
        _controller.document.insert(insertAt, '$prefixSpace$text');
        _controller.updateSelection(
          TextSelection.collapsed(
            offset: insertAt + text.length + (prefixSpace.isEmpty ? 0 : 1),
          ),
          quill.ChangeSource.local,
        );
      },
    );
  }

  Future<void> _shareAsDoc() async {
    final html = _deltaToSimpleHtml(_controller.document.toDelta());
    final tmp = await getTemporaryDirectory();
    final file =
    File('${tmp.path}/parte_${DateTime.now().millisecondsSinceEpoch}.doc');
    await file.writeAsString(_wrapWordHtml(html), flush: true);

    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/msword')],
      text: 'Parte diario',
    );
  }

  // ------- Render HTML sencillo desde Delta (sin quill_delta import) -------
  String _deltaToSimpleHtml(dynamic d) {
    final ops = (d as dynamic).toList();
    final lines = <_Line>[];
    var current = _Line();

    for (final op in ops) {
      final data = op.data;
      final attrs = (op.attributes ?? <String, dynamic>{}) as Map;

      if (data is String) {
        final parts = data.split('\n');
        for (var i = 0; i < parts.length; i++) {
          final seg = parts[i];
          if (seg.isNotEmpty) {
            current.runs.add(
              _Run(
                text: seg,
                bold: attrs['b'] == true || attrs['bold'] == true,
                italic: attrs['i'] == true || attrs['italic'] == true,
                underline: attrs['u'] == true || attrs['underline'] == true,
              ),
            );
          }
          if (i < parts.length - 1) {
            current.header =
            (attrs['header'] is int) ? attrs['header'] as int : null;
            current.list = attrs['list']?.toString();
            lines.add(current);
            current = _Line();
          }
        }
      }
    }
    if (current.runs.isNotEmpty) lines.add(current);

    String renderRuns(List<_Run> runs) {
      final sb = StringBuffer();
      for (final r in runs) {
        var t = _escapeHtml(r.text);
        if (r.underline) t = '<u>$t</u>';
        if (r.italic) t = '<i>$t</i>';
        if (r.bold) t = '<b>$t</b>';
        sb.write(t);
      }
      return sb.toString();
    }

    final buf = StringBuffer();
    var inUl = false;

    for (final l in lines) {
      final content = renderRuns(l.runs);
      final h = l.header ?? 0;
      final listType = l.list;

      if (listType == 'bullet') {
        if (!inUl) {
          buf.write('<ul>');
          inUl = true;
        }
        buf.write('<li>$content</li>');
        continue;
      } else if (inUl) {
        buf.write('</ul>');
        inUl = false;
      }

      if (h == 1) {
        buf.write('<h1>$content</h1>');
      } else if (h == 2) {
        buf.write('<h2>$content</h2>');
      } else if (h == 3) {
        buf.write('<h3>$content</h3>');
      } else {
        buf.write('<p>$content</p>');
      }
    }
    if (inUl) buf.write('</ul>');

    return buf.toString();
  }

  String _wrapWordHtml(String inner) {
    return '''
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Parte diario</title>
<style>
body { font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; font-size: 12pt; line-height: 1.4; color: #111; }
h1,h2,h3 { margin: 0 0 8px 0; }
p { margin: 0 0 8px 0; }
ul { margin: 0 0 8px 22px; }
</style>
</head>
<body>
$inner
</body>
</html>
''';
  }

  String _escapeHtml(String s) =>
      s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final bg = t.colorScheme.surface;
    final text = t.colorScheme.onSurface;

    return Stack(
      children: [
        // Hoja
        Container(
          height: MediaQuery.of(context).size.height * .96,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              // Top bar
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 8, 4),
                child: Row(
                  children: [
                    const SizedBox(width: 4),
                    Text(
                      'Bloc de notas',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                        color: text,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      tooltip: _listening ? 'Detener dictado' : 'Dictado',
                      onPressed: _toggleMic,
                      icon: Icon(_listening ? Icons.mic : Icons.mic_none),
                    ),
                    IconButton(
                      tooltip: 'Compartir como Word',
                      onPressed: _shareAsDoc,
                      icon: const Icon(Icons.ios_share_outlined),
                    ),
                    IconButton(
                      tooltip: 'Cerrar',
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
              ),

              // Toolbar propia
              _MiniToolbar(controller: _controller),

              const Divider(height: 1),

              // Editor (API clásica: controller + readOnly)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                  child: quill.QuillEditor.basic(
                    controller: _controller,
                    readOnly: false,
                  ),
                ),
              ),
            ],
          ),
        ),

        // CÁPSULA/ISLA arriba mientras escucha
        if (_listening)
          Positioned(
            top: 12,
            left: 0,
            right: 0,
            child: Center(
              child: _VoiceCapsule(level: _level, color: widget.accent),
            ),
          ),

        if (_loading)
          const Positioned.fill(
            child: ColoredBox(
              color: Color(0xAA000000),
              child: Center(child: CircularProgressIndicator()),
            ),
          ),
      ],
    );
  }
}

/// Toolbar minimalista para bold/italic/underline, H1/H2 y viñetas.
class _MiniToolbar extends StatelessWidget {
  const _MiniToolbar({required this.controller});
  final quill.QuillController controller;

  bool _isApplied(quill.Attribute attr) =>
      controller.getSelectionStyle().attributes.containsKey(attr.key);

  void _toggle(quill.Attribute attr) {
    if (_isApplied(attr)) {
      controller.formatSelection(quill.Attribute.clone(attr, null));
    } else {
      controller.formatSelection(attr);
    }
  }

  @override
  Widget build(BuildContext context) {
    final iconColor = Theme.of(context).colorScheme.primary;
    return SizedBox(
      height: 48,
      child: Row(
        children: [
          const SizedBox(width: 8),
          IconButton(
            tooltip: 'Negrita',
            icon: const Icon(Icons.format_bold),
            color: iconColor,
            onPressed: () => _toggle(quill.Attribute.bold),
          ),
          IconButton(
            tooltip: 'Cursiva',
            icon: const Icon(Icons.format_italic),
            color: iconColor,
            onPressed: () => _toggle(quill.Attribute.italic),
          ),
          IconButton(
            tooltip: 'Subrayado',
            icon: const Icon(Icons.format_underline),
            color: iconColor,
            onPressed: () => _toggle(quill.Attribute.underline),
          ),
          const VerticalDivider(width: 10),
          IconButton(
            tooltip: 'H1',
            icon: const Icon(Icons.title),
            color: iconColor,
            onPressed: () => controller.formatSelection(quill.Attribute.h1),
          ),
          IconButton(
            tooltip: 'H2',
            icon: const Icon(Icons.title_outlined),
            color: iconColor,
            onPressed: () => controller.formatSelection(quill.Attribute.h2),
          ),
          const VerticalDivider(width: 10),
          IconButton(
            tooltip: 'Viñetas',
            icon: const Icon(Icons.format_list_bulleted),
            color: iconColor,
            onPressed: () => _toggle(quill.Attribute.ul),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}

class _VoiceCapsule extends StatelessWidget {
  const _VoiceCapsule({required this.level, required this.color});
  final double level; // 0..1
  final Color color;

  @override
  Widget build(BuildContext context) {
    final w = 220.0 + 60.0 * level; // “onda” horizontal
    const h = 42.0;
    final glow = color.withValues(alpha: .35);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 120),
      curve: Curves.easeOutCubic,
      width: w,
      height: h,
      decoration: BoxDecoration(
        color: color.withValues(alpha: .15),
        borderRadius: BorderRadius.circular(h),
        border: Border.all(color: color.withValues(alpha: .35), width: 1),
        boxShadow: [
          BoxShadow(
            color: glow,
            blurRadius: 18,
            spreadRadius: -2,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Icon(Icons.graphic_eq, color: color, size: 18 + 6 * level),
          const SizedBox(width: 10),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: _LevelBar(level: level, color: color),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'Escuchando…',
            style: TextStyle(color: color, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _LevelBar extends StatelessWidget {
  const _LevelBar({required this.level, required this.color});
  final double level;
  final Color color;

  @override
  Widget build(BuildContext context) {
    const bars = 14;
    final active = (level * bars).round().clamp(0, bars);
    return Row(
      children: List.generate(bars, (i) {
        final on = i < active;
        final h = 8.0 + math.sin((i / bars) * math.pi) * 8.0;
        return Expanded(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            height: h,
            margin: const EdgeInsets.symmetric(horizontal: 1.5, vertical: 8),
            decoration: BoxDecoration(
              color: on ? color : color.withValues(alpha: .18),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        );
      }),
    );
  }
}

class _Run {
  final String text;
  final bool bold, italic, underline;
  _Run({
    required this.text,
    this.bold = false,
    this.italic = false,
    this.underline = false,
  });
}

class _Line {
  final List<_Run> runs;
  int? header;
  String? list;
  _Line() : runs = [];
}
