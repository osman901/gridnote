import 'package:flutter/material.dart';
import '../services/license_manager.dart';
import '../screens/license_activation_screen.dart';

class LicenseGate extends StatefulWidget {
  const LicenseGate({super.key, required this.child, required this.manager});
  final Widget child;
  final LicenseManager manager;

  @override
  State<LicenseGate> createState() => _LicenseGateState();
}

class _LicenseGateState extends State<LicenseGate> {
  LicenseStatus? _status;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await widget.manager.initialize();
    final s = await widget.manager.status();
    if (!mounted) return;
    setState(() { _status = s; _loading = false; });
  }

  Future<void> _onActivated() async {
    final s = await widget.manager.status();
    if (!mounted) return;
    setState(() { _status = s; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      final isDark = Theme.of(context).brightness == Brightness.dark;
      return Scaffold(
        backgroundColor: isDark ? Colors.black : Colors.white,
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final s = _status!;
    if (s.allowed) return widget.child;

    return LicenseActivationScreen(manager: widget.manager, status: s, onActivated: _onActivated);
  }
}
