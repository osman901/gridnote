﻿// lib/services/location_service.dart
import 'dart:async';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart'
    show ValueListenable, debugPrint, debugPrintStack;
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import '../utils/geo_utils.dart';
import 'ux/smart_notifier.dart';

/// Token de cancelación: pasa un ValueNotifier<bool>(false) como [CancelToken].
typedef CancelToken = ValueListenable<bool>;

/// Error controlado para flujos de ubicación.
class LocationException implements Exception {
  final String message;
  const LocationException(this.message);
  @override
  String toString() => 'LocationException: $message';
}

/// Resultado de ubicación con metadatos útiles.
class LocationFix {
  final double latitude;
  final double longitude;
  final double? accuracyMeters; // ~68% radio estimado
  final double? altitudeMeters;
  final double? speedMps;
  final double? headingDeg;
  final DateTime timestamp;
  final int usedSamples;
  final int discardedSamples;

  const LocationFix({
    required this.latitude,
    required this.longitude,
    this.accuracyMeters,
    this.altitudeMeters,
    this.speedMps,
    this.headingDeg,
    required this.timestamp,
    this.usedSamples = 1,
    this.discardedSamples = 0,
  });

  factory LocationFix.fromPosition(
      Position p, {
        int used = 1,
        int discarded = 0,
      }) {
    return LocationFix(
      latitude: p.latitude,
      longitude: p.longitude,
      accuracyMeters: _finiteOrNull(p.accuracy),
      altitudeMeters: _finiteOrNull(p.altitude),
      speedMps: _finiteOrNull(p.speed),
      headingDeg: _finiteOrNull(p.heading),
      timestamp: p.timestamp,
      usedSamples: used,
      discardedSamples: discarded,
    );
  }

  String toGeoUri({String? label}) =>
      GeoUtils.geoUri(latitude, longitude, label: label).toString();

  Uri toMapsUri() => GeoUtils.mapsUri(latitude, longitude);

  Map<String, dynamic> toJson() => {
    'lat': latitude,
    'lng': longitude,
    'accuracy': accuracyMeters,
    'alt': altitudeMeters,
    'speed': speedMps,
    'heading': headingDeg,
    'ts': timestamp.toUtc().toIso8601String(),
    'samples_used': usedSamples,
    'samples_discarded': discardedSamples,
  };

  static double? _finiteOrNull(double v) {
    if (v.isNaN || v.isInfinite) return null;
    return v;
  }
}

class LocationService {
  LocationService._();
  static final LocationService instance = LocationService._();

  static const Duration _getCurrentTimeout = Duration(seconds: 8);

  // ---------- permisos ----------
  Future<void> _ensureServiceAndPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw const LocationException('Servicio de ubicación desactivado');
    }

    var perm = await Geolocator.checkPermission();

    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied) {
        SmartNotifier.instance.error('Permiso de ubicación denegado.');
        throw const LocationException('Permiso de ubicación denegado');
      }
    }

    if (perm == LocationPermission.deniedForever) {
      SmartNotifier.instance.warn(
        'Para usar el GPS, activá los permisos desde la configuración de la app.',
      );
      throw const LocationException(
        'Permisos de ubicación denegados para siempre',
      );
    }
  }

  Future<bool> hasPermission() async {
    final perm = await Geolocator.checkPermission();
    return perm == LocationPermission.always ||
        perm == LocationPermission.whileInUse;
  }

  Future<bool> ensureFullAccuracy({String? iosPurposeKey}) async {
    final status = await Geolocator.getLocationAccuracy();
    if (status == LocationAccuracyStatus.precise) return true;

    if (Platform.isIOS) {
      try {
        final result = await Geolocator.requestTemporaryFullAccuracy(
          purposeKey: iosPurposeKey ?? 'FullAccuracyUsage',
        );
        return result == LocationAccuracyStatus.precise;
      } catch (_) {}
    }
    return false;
  }

  Future<void> openSystemLocationSettings() async {
    await Geolocator.openLocationSettings();
  }

  Future<void> openAppSettings() async {
    await Geolocator.openAppSettings();
  }

  // ---------- lecturas rápidas ----------
  Future<LocationFix> getCurrentFix({
    LocationAccuracy? desiredAccuracy,
    Duration timeout = _getCurrentTimeout,
    bool rejectMocked = true,
    bool tryFullAccuracyIOS = false,
    String? iosPurposeKey,
  }) async {
    final p = await getCurrent(
      desiredAccuracy: desiredAccuracy,
      timeout: timeout,
      rejectMocked: rejectMocked,
      tryFullAccuracyIOS: tryFullAccuracyIOS,
      iosPurposeKey: iosPurposeKey,
    );
    return LocationFix.fromPosition(p);
  }

  Future<Position> getCurrent({
    LocationAccuracy? desiredAccuracy,
    Duration timeout = _getCurrentTimeout,
    bool rejectMocked = true,
    bool tryFullAccuracyIOS = false,
    String? iosPurposeKey,
  }) async {
    await _ensureServiceAndPermission();

    if (tryFullAccuracyIOS && Platform.isIOS) {
      await ensureFullAccuracy(iosPurposeKey: iosPurposeKey);
    }

    final acc = desiredAccuracy ??
        (Platform.isIOS
            ? LocationAccuracy.bestForNavigation
            : LocationAccuracy.best);

    try {
      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: acc,
        timeLimit: timeout,
      );
      if (!_validPos(p, rejectMocked: rejectMocked)) {
        throw const LocationException('Fix inválido (0,0 o precisión no válida)');
      }
      return p;
    } on TimeoutException {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && _validPos(last, rejectMocked: rejectMocked)) {
        return last;
      }
      throw const LocationException('Tiempo de espera agotado obteniendo ubicación');
    } catch (e, st) {
      _logError(e, st);
      throw LocationException('No se pudo obtener la ubicación: $e');
    }
  }

  Future<Position?> getLastKnown() => Geolocator.getLastKnownPosition();

  // ---------- lecturas precisas ----------
  Future<LocationFix> getPreciseFix({
    int samples = 6,
    Duration perSampleTimeout = const Duration(seconds: 4),
    double keepBestFraction = 0.6,
    bool rejectMocked = true,
    double minUniqueMeters = 0.5,
    LocationAccuracy? desiredAccuracy,
    bool tryFullAccuracyIOS = false,
    String? iosPurposeKey,
    CancelToken? cancelToken,
  }) async {
    assert(samples > 0 && keepBestFraction > 0 && keepBestFraction <= 1);

    await _ensureServiceAndPermission();
    _throwIfCancelled(cancelToken);

    if (tryFullAccuracyIOS && Platform.isIOS) {
      await ensureFullAccuracy(iosPurposeKey: iosPurposeKey);
    }

    final desired = desiredAccuracy ??
        (Platform.isIOS
            ? LocationAccuracy.bestForNavigation
            : LocationAccuracy.best);

    final List<Position> bucket = [];
    int discarded = 0;
    Position? lastAccepted;

    for (var i = 0; i < samples; i++) {
      _throwIfCancelled(cancelToken);
      try {
        final p = await Geolocator.getCurrentPosition(
          desiredAccuracy: desired,
        ).timeout(perSampleTimeout);

        if (_validPos(p, rejectMocked: rejectMocked)) {
          final la = lastAccepted;
          if (la == null ||
              Geolocator.distanceBetween(
                la.latitude,
                la.longitude,
                p.latitude,
                p.longitude,
              ) >=
                  minUniqueMeters) {
            bucket.add(p);
            lastAccepted = p;
          } else {
            discarded++;
          }
        } else {
          discarded++;
        }
      } on TimeoutException {
        discarded++;
      } catch (_) {
        discarded++;
      }
      await Future<void>.delayed(const Duration(milliseconds: 250));
    }

    if (bucket.isEmpty) {
      throw const LocationException('Sin lecturas de GPS disponibles');
    }

    return _processLocationBucket(
      bucket: bucket,
      discardedCount: discarded,
      keepBestFraction: keepBestFraction,
    );
  }

  /// Ultra-fix SOLO con stream: timeout/cupo + cancelación cooperativa.
  Future<LocationFix> getUltraFix({
    int maxSamples = 10,
    Duration overallTimeout = const Duration(seconds: 18),
    double keepBestFraction = 0.6,
    bool rejectMocked = true,
    double minUniqueMeters = 0.5,
    LocationAccuracy? desiredAccuracy,
    bool tryFullAccuracyIOS = false,
    String? iosPurposeKey,
    CancelToken? cancelToken,
  }) async {
    assert(maxSamples > 0 && keepBestFraction > 0 && keepBestFraction <= 1);

    await _ensureServiceAndPermission();

    if (tryFullAccuracyIOS && Platform.isIOS) {
      await ensureFullAccuracy(iosPurposeKey: iosPurposeKey);
    }

    final desired = desiredAccuracy ??
        (Platform.isIOS
            ? LocationAccuracy.bestForNavigation
            : LocationAccuracy.best);

    final bucket = <Position>[];
    var discarded = 0;

    DateTime lastAt = DateTime.fromMillisecondsSinceEpoch(0);
    Position? lastAccepted;
    const debounce = Duration(milliseconds: 250);

    final stream = Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: desired,
        distanceFilter: 0,
      ),
    );

    final completer = Completer<void>();
    late final StreamSubscription<Position> sub;
    Timer? killer;
    bool cancelled = false;

    void tryFinish() {
      if (!completer.isCompleted) completer.complete();
    }

    void onCancelChanged() {
      if (cancelToken?.value == true) {
        cancelled = true;
        tryFinish();
      }
    }

    final cancelListener = cancelToken == null ? null : onCancelChanged;

    sub = stream.listen((pos) {
      if (cancelToken?.value == true) {
        cancelled = true;
        tryFinish();
        return;
      }

      final now = DateTime.now();
      if (now.difference(lastAt) < debounce) return;

      if (_validPos(pos, rejectMocked: rejectMocked)) {
        final la = lastAccepted;
        if (la == null ||
            Geolocator.distanceBetween(
              la.latitude,
              la.longitude,
              pos.latitude,
              pos.longitude,
            ) >=
                minUniqueMeters) {
          lastAt = now;
          lastAccepted = pos;
          bucket.add(pos);
          if (bucket.length >= maxSamples) {
            tryFinish();
          }
        } else {
          discarded++;
        }
      } else {
        discarded++;
      }
    }, onError: (e, st) {
      _logError(e, st);
    });

    killer = Timer(overallTimeout, tryFinish);

    if (cancelListener != null) {
      cancelToken!.addListener(cancelListener);
    }

    await completer.future;

    await sub.cancel();
    killer.cancel();

    if (cancelListener != null) {
      cancelToken!.removeListener(cancelListener);
    }

    if (cancelled) {
      throw const LocationException('Operación cancelada');
    }

    if (bucket.isEmpty) {
      throw const LocationException('Sin lecturas válidas');
    }

    return _processLocationBucket(
      bucket: bucket,
      discardedCount: discarded,
      keepBestFraction: keepBestFraction,
    );
  }

  // ---------- utilidades ----------
  String mapsUrl(double lat, double lng) =>
      GeoUtils.mapsUri(lat, lng).toString();

  Future<bool> openInMaps({
    required double lat,
    required double lng,
    String? label,
  }) async {
    if (!GeoUtils.isValid(lat, lng)) return false;
    final geo = GeoUtils.geoUri(lat, lng, label: label);
    if (await canLaunchUrl(geo)) {
      return launchUrl(geo, mode: LaunchMode.externalApplication);
    }
    final web = GeoUtils.mapsUri(lat, lng);
    return launchUrl(web, mode: LaunchMode.externalApplication);
  }

  String shareTextFor(double lat, double lng, {String? label}) {
    final ok = GeoUtils.isValid(lat, lng);
    final fLat = ok ? GeoUtils.fmt(lat) : '-';
    final fLng = ok ? GeoUtils.fmt(lng) : '-';
    final geo = ok ? GeoUtils.geoUri(lat, lng, label: label).toString() : '';
    final web = ok ? GeoUtils.mapsUri(lat, lng).toString() : '';
    return 'Ubicación: $fLat, $fLng\n$geo\n$web';
  }

  bool _validPos(Position p, {bool rejectMocked = true}) {
    if (!GeoUtils.isValid(p.latitude, p.longitude)) return false;
    if (!p.accuracy.isFinite || p.accuracy <= 0) return false;
    if (rejectMocked && p.isMocked == true) return false;
    return true;
  }

  void _throwIfCancelled(CancelToken? t) {
    if (t?.value == true) {
      throw const LocationException('Operación cancelada');
    }
  }

  /// DRY: procesa bucket y devuelve LocationFix promedio con precisión robusta.
  LocationFix _processLocationBucket({
    required List<Position> bucket,
    required int discardedCount,
    required double keepBestFraction,
  }) {
    bucket.sort((a, b) => a.accuracy.compareTo(b.accuracy));
    final keepNum =
    (bucket.length * keepBestFraction).clamp(1, bucket.length).toInt();
    final kept = bucket.take(keepNum).toList();

    final avgLat =
        kept.map((p) => p.latitude).reduce((a, b) => a + b) / kept.length;
    final avgLng =
        kept.map((p) => p.longitude).reduce((a, b) => a + b) / kept.length;

    if (!GeoUtils.isValid(avgLat, avgLng)) {
      throw const LocationException('Fix inválido (0,0)');
    }

    final dists = kept
        .map((p) => Geolocator.distanceBetween(
      avgLat,
      avgLng,
      p.latitude,
      p.longitude,
    ))
        .toList()
      ..sort();
    final medianDist = dists[dists.length ~/ 2];

    // Convierte la Desviación Absoluta Mediana (MAD) a σ aprox (1.4826).
    final estAccuracy = medianDist * 1.4826;
    final bestReported = kept.first.accuracy;
    final accuracy = estAccuracy > bestReported ? estAccuracy : bestReported;

    final ref = kept.first;
    return LocationFix(
      latitude: avgLat,
      longitude: avgLng,
      accuracyMeters: LocationFix._finiteOrNull(accuracy),
      altitudeMeters: LocationFix._finiteOrNull(ref.altitude),
      speedMps: LocationFix._finiteOrNull(ref.speed),
      headingDeg: LocationFix._finiteOrNull(ref.heading),
      timestamp: ref.timestamp,
      usedSamples: kept.length,
      discardedSamples: discardedCount + (bucket.length - kept.length),
    );
  }

  void _logError(Object e, StackTrace st) {
    debugPrint('LocationService error: $e');
    debugPrintStack(stackTrace: st);
  }
}

extension LocationCapture on LocationService {
  /// Captura exacta solo con stream. Lanza excepción si falla o se cancela.
  Future<LocationFix> captureExact({
    Duration warmup = const Duration(seconds: 7),
    Duration timeout = const Duration(seconds: 15),
    double targetAccuracyMeters = 25,
    bool rejectMocked = true,
    bool tryFullAccuracyIOS = false,
    String? iosPurposeKey,
    CancelToken? cancelToken,
  }) async {
    await _ensureServiceAndPermission();
    if (tryFullAccuracyIOS && Platform.isIOS) {
      await ensureFullAccuracy(iosPurposeKey: iosPurposeKey);
    }
    if (cancelToken?.value == true) {
      throw const LocationException('Operación cancelada');
    }

    Position? best = await Geolocator.getLastKnownPosition();
    if (best != null && !GeoUtils.isValid(best.latitude, best.longitude)) {
      best = null;
    }

    final stream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 0,
      ),
    );

    final completer = Completer<Position?>();
    late final StreamSubscription<Position> sub;

    Timer? warmTimer;
    Timer? killTimer;
    var isFinishing = false;
    bool cancelled = false;

    Future<void> finish(Position? p) async {
      if (isFinishing) return;
      isFinishing = true;
      warmTimer?.cancel();
      killTimer?.cancel();
      await sub.cancel();
      if (!completer.isCompleted) completer.complete(p);
    }

    void onCancelChanged() {
      if (cancelToken?.value == true) {
        cancelled = true;
        // ignore: discarded_futures
        finish(best);
      }
    }

    if (cancelToken != null) {
      cancelToken.addListener(onCancelChanged);
    }

    sub = stream.listen((pos) async {
      if (rejectMocked && pos.isMocked == true) return;
      if (!GeoUtils.isValid(pos.latitude, pos.longitude)) return;

      if (best == null || pos.accuracy < best!.accuracy) {
        best = pos;
        if (pos.accuracy <= targetAccuracyMeters) {
          await finish(best);
        }
      }
    }, onError: (e, st) async {
      _logError(e, st);
      try {
        final p = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.bestForNavigation,
          timeLimit: const Duration(seconds: 5),
        );
        if (GeoUtils.isValid(p.latitude, p.longitude)) {
          await finish(p);
        } else {
          await finish(best);
        }
      } catch (_) {
        await finish(best);
      }
    });

    warmTimer = Timer(warmup, () async {
      if (best != null && best!.accuracy <= targetAccuracyMeters) {
        await finish(best);
      }
    });

    killTimer = Timer(timeout, () async => finish(best));

    final primary = await completer.future;

    if (cancelToken != null) {
      cancelToken.removeListener(onCancelChanged);
    }

    if (cancelled) {
      throw const LocationException('Operación cancelada');
    }

    if (primary == null ||
        !GeoUtils.isValid(primary.latitude, primary.longitude)) {
      throw const LocationException('Sin lecturas válidas');
    }

    return LocationFix.fromPosition(primary);
  }

  /// Si no hay fix previo, intenta capturar uno exacto.
  Future<LocationFix> freezeIfEmpty(
      LocationFix? existing, {
        CancelToken? cancelToken,
      }) async {
    if (existing != null) return existing;
    return captureExact(cancelToken: cancelToken);
  }
}
