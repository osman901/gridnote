﻿// lib/models/free_sheet.dart
import 'attachment.dart';

class FreeSheetData {
  String id;
  String name;
  DateTime createdAt;
  List<String> headers;
  List<List<String>> rows;

  FreeSheetData({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.headers,
    required this.rows,
  });

  // ======== Compatibilidad: métodos mutables que ya usás ========

  void ensureWidth(int cols) {
    if (cols < 1) cols = 1;
    if (headers.length < cols) {
      headers.addAll(List.filled(cols - headers.length, ''));
    }
    for (final r in rows) {
      if (r.length < cols) {
        r.addAll(List.filled(cols - r.length, ''));
      }
    }
  }

  void ensureHeight(int count) {
    if (count < 0) count = 0;
    while (rows.length < count) {
      rows.add(List.filled(headers.length, ''));
    }
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'createdAt': createdAt.toIso8601String(),
    'headers': headers,
    'rows': rows,
  };

  static FreeSheetData fromMap(Map map) => FreeSheetData(
    id: (map['id'] ?? '').toString(),
    name: (map['name'] ?? 'Planilla libre').toString(),
    createdAt: DateTime.tryParse(map['createdAt']?.toString() ?? '') ??
        DateTime.now(),
    headers: List<String>.from(
      (map['headers'] as List?)
          ?.map((e) => e?.toString() ?? '') ??
          const [],
    ),
    rows: List<List>.from(map['rows'] as List? ?? const [])
        .map<List<String>>(
            (r) => List<String>.from(r.map((e) => e?.toString() ?? '')))
        .toList(),
  );

  // ======== Nuevos helpers INMUTABLES (no rompen nada existente) ========

  FreeSheetData copyWith({
    String? id,
    String? name,
    DateTime? createdAt,
    List<String>? headers,
    List<List<String>>? rows,
  }) {
    return FreeSheetData(
      id: id ?? this.id,
      name: name ?? this.name,
      createdAt: createdAt ?? this.createdAt,
      headers: headers ?? List<String>.from(this.headers),
      rows: rows != null
          ? rows.map((r) => List<String>.from(r)).toList()
          : this.rows.map((r) => List<String>.from(r)).toList(),
    );
  }

  /// Cambia el contenido de una celda devolviendo una NUEVA instancia.
  FreeSheetData withCellChanged(int r, int c, String value) {
    final nr = rows.map((row) => List<String>.from(row)).toList();
    // Asegura límites
    if (r >= nr.length) {
      final add = r - nr.length + 1;
      for (int i = 0; i < add; i++) {
        nr.add(List.filled(headers.length, ''));
      }
    }
    if (c >= headers.length) {
      final nh = List<String>.from(headers);
      nh.addAll(List.filled(c - nh.length + 1, ''));
      // expandir todas las filas existentes
      for (final row in nr) {
        row.addAll(List.filled(nh.length - row.length, ''));
      }
      return FreeSheetData(
        id: id,
        name: name,
        createdAt: createdAt,
        headers: nh,
        rows: _setCell(nr, r, c, value),
      );
    }
    return copyWith(rows: _setCell(nr, r, c, value));
  }

  List<List<String>> _setCell(List<List<String>> nr, int r, int c, String v) {
    nr[r][c] = v;
    return nr;
  }

  /// Garantiza que exista la columna "Adjuntos". Devuelve (dataNueva, indexCol).
  (FreeSheetData, int) ensureAttachmentColumn() {
    const title = 'Adjuntos';
    var idx = headers.indexOf(title);
    if (idx != -1) return (this, idx);

    final nh = List<String>.from(headers)..add(title);
    final nr = rows.map((r) {
      final copy = List<String>.from(r);
      copy.add('');
      return copy;
    }).toList();

    final nd = copyWith(headers: nh, rows: nr);
    return (nd, nh.length - 1);
  }

  // ======== Adjuntos tipados en una celda (JSON en el string) ========

  /// Devuelve la lista de adjuntos guardada en la celda (JSON) o [] si no hay.
  List<Attachment> attachmentsAt(int r, int c) {
    if (r < 0 || c < 0 || r >= rows.length || c >= headers.length) {
      return const [];
    }
    final raw = rows[r][c];
    if (raw.isEmpty || raw.trimLeft().isEmpty) return const [];
    if (!raw.trimLeft().startsWith('[')) return const []; // no es JSON
    return Attachment.decodeList(raw);
  }

  /// Reemplaza todos los adjuntos de una celda.
  FreeSheetData withAttachmentsSet(int r, int c, List<Attachment> items) {
    final json = Attachment.encodeList(items);
    return withCellChanged(r, c, json);
  }

  /// Agrega un adjunto a la celda (acumula).
  FreeSheetData withAttachmentAdded(int r, int c, Attachment a) {
    final curr = attachmentsAt(r, c);
    final next = [...curr, a];
    return withAttachmentsSet(r, c, next);
  }
}
