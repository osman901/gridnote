/// Stub: no hace dictado real, pero mantiene la API.
/// Si luego agregÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡s speech_to_text, podÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s implementarlo acÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡.
class VoiceDictation {
  VoiceDictation._();
  static final VoiceDictation instance = VoiceDictation._();

  Future<String?> listenOnce() async {
    // TODO: integrar speech_to_text o similar
    return null;
  }
}
