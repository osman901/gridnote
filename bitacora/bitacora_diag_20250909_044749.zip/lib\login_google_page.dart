import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'service_locator.dart';  // para lista de correos permitidos

class LoginGooglePage extends StatefulWidget {
  const LoginGooglePage({super.key});
  @override
  State<LoginGooglePage> createState() => _LoginGooglePageState();
}

class _LoginGooglePageState extends State<LoginGooglePage> {
  bool _loading = false;
  String? _error;

  Future<void> _signInWithGoogle() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) {
        if (!mounted) return;
        setState(() => _loading = false);
        return;
      }
      final gAuth = await googleUser.authentication;
      final cred = GoogleAuthProvider.credential(
        accessToken: gAuth.accessToken, idToken: gAuth.idToken,
      );
      await FirebaseAuth.instance.signInWithCredential(cred);
      // Verificar licencia del usuario autenticado
      final user = FirebaseAuth.instance.currentUser;
      final allowedEmails = getIt<List<String>>();
      if (user != null) {
        final email = user.email;
        if (email == null || !allowedEmails.contains(email.toLowerCase())) {
          // Correo no autorizado: cerrar sesiÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³n y mostrar mensaje de error
          await FirebaseAuth.instance.signOut();
          if (!mounted) return;
          setState(() {
            _loading = false;
            _error = 'Este correo no estÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ autorizado para usar la aplicaciÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³n';
          });
          return;
        }
      }
      if (!mounted) return;
      setState(() { _loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Center(
        child: _loading
            ? const CircularProgressIndicator()
            : Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
            FilledButton.icon(
              onPressed: _signInWithGoogle,
              icon: const Icon(Icons.login),
              label: const Text('Continuar con Google'),
              style: FilledButton.styleFrom(
                backgroundColor: theme.colorScheme.secondary,
                foregroundColor: Colors.black87,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
