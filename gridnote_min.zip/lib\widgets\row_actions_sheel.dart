import 'package:flutter/material.dart';
import '../services/attachments_service.dart';
import '../screens/attachments_gallery_screen.dart';

class RowActionsSheet extends StatelessWidget {
  final dynamic measurementKey;
  const RowActionsSheet({super.key, required this.measurementKey});

  Future<void> _attachPhoto(BuildContext context) async {
    // Evitar usar `context` luego de `await`
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final svc = AttachmentsService.instance as dynamic;

    String? value;

    try {
      // 1) Preferí métodos “con clave” si existen en tu service
      value = await (svc.capturePhotoToKey?.call(measurementKey) ??
          svc.addPhotoToKey?.call(measurementKey) ??
          // 2) Si no existen, probá cámara/galería y luego intentá guardar con la key
          svc.capturePhoto?.call(context) ??
          svc.addPhoto?.call(context) ??
          // 3) Último recurso: placeholder
          svc.addPhotoPlaceholder?.call());

      // Si obtuvimos un path/URL pero no lo guardó “con key” directamente,
      // intentamos persistirlo manualmente con algún método común.
      if (value is String && value.isNotEmpty) {
        // Intenta varias firmas comunes sin romper si no existen:
        await (svc.attachToKey?.call(measurementKey, value) ??
            svc.saveAttachment?.call(measurementKey, value) ??
            svc.savePhotoForKey?.call(measurementKey, value) ??
            Future.value());
      }
    } catch (_) {
      // Si algo falla, intentamos al menos un placeholder
      try {
        value ??= await svc.addPhotoPlaceholder?.call();
        if (value is String && value.isNotEmpty) {
          await (svc.attachToKey?.call(measurementKey, value) ??
              svc.saveAttachment?.call(measurementKey, value) ??
              Future.value());
        }
      } catch (_) {}
    }

    if (value == null || (value is String && value.isEmpty)) {
      messenger.showSnackBar(const SnackBar(content: Text('Foto cancelada')));
      return;
    }

    messenger.showSnackBar(const SnackBar(content: Text('Foto adjuntada')));
    navigator.pop(); // cerrar el sheet
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Wrap(
        children: [
          ListTile(
            leading: const Icon(Icons.camera_alt_outlined),
            title: const Text('Adjuntar foto (cámara)'),
            onTap: () => _attachPhoto(context),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Ver adjuntos'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AttachmentsGalleryScreen(
                    measurementKey: measurementKey,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

