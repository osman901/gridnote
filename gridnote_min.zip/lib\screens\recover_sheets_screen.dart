// lib/screens/recover_sheets_screen.dart
import 'package:flutter/material.dart';
import '../theme/gridnote_theme.dart';

class RecoverSheetsScreen extends StatelessWidget {
  const RecoverSheetsScreen({super.key, required this.theme});
  final GridnoteThemeController theme;

  @override
  Widget build(BuildContext context) {
    final t = theme.theme;

    // Esta versión muestra UI y “mock” de elementos recuperables.
    // Luego conectamos con tu servicio de papelera.
    final mock = <_TrashItem>[
      // Deja vacía la lista si aún no implementaste papelera.
      // _TrashItem('Planilla nueva — sáb 19:36', DateTime.now().subtract(const Duration(hours: 2))),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Recuperar planillas')),
      body: mock.isEmpty
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'No hay planillas en papelera.\n\n'
                'Cuando implementemos el borrado suave, las planillas '
                'eliminadas aparecerán aquí hasta un plazo de recuperación.',
            textAlign: TextAlign.center,
            style:
            TextStyle(color: t.text.withValues(alpha: .7), height: 1.4),
          ),
        ),
      )
          : ListView.separated(
        padding: const EdgeInsets.all(12),
        itemBuilder: (_, i) {
          final it = mock[i];
          return ListTile(
            leading: const Icon(Icons.description_outlined),
            title: Text(it.title),
            subtitle: Text(
              'Eliminada hace ${_ago(it.deletedAt)}',
              style: TextStyle(color: t.text.withValues(alpha: .7)),
            ),
            trailing: FilledButton(
              onPressed: () {
                // TODO: Restaurar usando tu servicio
                ScaffoldMessenger.of(_).showSnackBar(
                  const SnackBar(content: Text('Restaurado (demo)')),
                );
              },
              child: const Text('Restaurar'),
            ),
          );
        },
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemCount: mock.length,
      ),
    );
  }

  static String _ago(DateTime d) {
    final diff = DateTime.now().difference(d);
    if (diff.inMinutes < 60) return '${diff.inMinutes} min';
    if (diff.inHours < 24) return '${diff.inHours} h';
    return '${diff.inDays} d';
  }
}

class _TrashItem {
  final String title;
  final DateTime deletedAt;
  _TrashItem(this.title, this.deletedAt);
}
