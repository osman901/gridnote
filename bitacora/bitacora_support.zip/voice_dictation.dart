﻿/// Stub: no hace dictado real, pero mantiene la API.
/// Si luego agregÃ¡s speech_to_text, podÃ©s implementarlo acÃ¡.
class VoiceDictation {
  VoiceDictation._();
  static final VoiceDictation instance = VoiceDictation._();

  Future<String?> listenOnce() async {
    // TODO: integrar speech_to_text o similar
    return null;
  }
}
