plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // El de Flutter debe ir después de Android/Kotlin
    id("dev.flutter.flutter-gradle-plugin")
    // Necesario para Firebase
    id("com.google.gms.google-services")
}

android {
    namespace = "com.gridnote.bitacora"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    defaultConfig {
        applicationId = "com.gridnote.bitacora"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        debug { isMinifyEnabled = false; isShrinkResources = false }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
}

flutter {
    source = "../.."
}

dependencies {
    // Desugaring para APIs Java 8+
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.2")
}
