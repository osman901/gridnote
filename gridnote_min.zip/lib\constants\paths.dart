class AppPaths {
  static const String logo = 'assets/logo.png';
// Sumá otros paths globales si tenés, ej: imágenes o plantillas
}
