import 'package:flutter/material.dart';

class TrashPage extends StatelessWidget {
  const TrashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Papelera')),
      body: const Center(
        child: Text('AcÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ va tu UI de recuperar datos borrados.'),
      ),
    );
  }
}
