package com.gridnote.bitacora

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
