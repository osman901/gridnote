// lib/services/dictation_service.dart
import 'dart:async';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class DictationState {
  final bool available;
  final bool listening;
  final double level; // 0..1 normalizado
  const DictationState({required this.available, required this.listening, required this.level});

  DictationState copyWith({bool? available, bool? listening, double? level}) =>
      DictationState(
        available: available ?? this.available,
        listening: listening ?? this.listening,
        level: level ?? this.level,
      );
}

class DictationService {
  DictationService._();
  static final instance = DictationService._();

  final _stt = stt.SpeechToText();
  final _stateCtrl = StreamController<DictationState>.broadcast();
  DictationState _state = const DictationState(available: false, listening: false, level: 0);
  Stream<DictationState> get states => _stateCtrl.stream;
  bool get isListening => _state.listening;

  Future<bool> init({String? localeId}) async {
    final ok = await _stt.initialize(
      onStatus: (s) {
        final listening = s.toLowerCase().contains('listening') || s.toLowerCase().contains('notListening') == false && _stt.isListening;
        _emit(_state.copyWith(listening: listening));
      },
      onError: (_) => _emit(_state.copyWith(listening: false, level: 0)),
      debugLogging: false,
    );
    _emit(_state.copyWith(available: ok));
    return ok;
  }

  Future<void> start({
    String localeId = 'es_AR',
    void Function(String chunk)? onChunk,
  }) async {
    if (!_state.available) {
      final ok = await init(localeId: localeId);
      if (!ok) return;
    }
    await _stt.listen(
      localeId: localeId,
      onResult: (r) {
        final text = r.recognizedWords.trim();
        if (text.isNotEmpty && onChunk != null) onChunk(text);
      },
      listenMode: stt.ListenMode.dictation,
      partialResults: true,
      onSoundLevelChange: (level) {
        final norm = (level / 20.0).clamp(0.0, 1.0);
        _emit(_state.copyWith(level: norm));
      },
    );
    _emit(_state.copyWith(listening: true));
  }

  Future<void> stop() async {
    await _stt.stop();
    _emit(_state.copyWith(listening: false, level: 0));
  }

  Future<void> cancel() async {
    await _stt.cancel();
    _emit(_state.copyWith(listening: false, level: 0));
  }

  void _emit(DictationState s) {
    _state = s;
    _stateCtrl.add(s);
  }

  void dispose() {
    _stateCtrl.close();
  }
}
