// Bitácora · Pluto edit activity bridge · 2025-09
// Seguro con null-safety. Sin dependencias internas de PlutoGrid.
// No usa BuildContext ni listeners que goteen memoria.

import 'dart:async';
import 'package:pluto_grid/pluto_grid.dart';

/// Bridge mínimo para marcar actividad de edición/teclado.
/// Podés enchufar analytics o UX aquí sin tocar el grid.
class PlutoEditActivityBridge {
  PlutoEditActivityBridge(this._sm);

  final PlutoGridStateManager _sm;

  // Dejalo por si querés enganchar un stream propio en el futuro.
  StreamSubscription<void>? _sub;

  /// Llamado desde PlutoGrid.onChanged(...)
  void handleOnChanged(PlutoGridOnChangedEvent e) {
    // Ejemplo:
    // UsageAnalytics.instance.bump('edit_${e.column.field}');
    // SmartNotifier.instance.trace('Edit: ${e.column.field}');
  }

  void dispose() {
    _sub?.cancel();
    _sub = null;
  }
}
