import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/app_db.dart';      // <- usamos SheetRow de Drift
import '../providers.dart';
import 'sheet_editor_screen.dart';

class BrowseSheetsScreen extends ConsumerWidget {
  const BrowseSheetsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sheetsAsync = ref.watch(sheetsProvider);

    Future<void> createSheet() async {
      final repo = ref.read(sheetsRepoProvider);
      final s = await repo.createSheet(
        name: 'Planilla ${DateTime.now().millisecondsSinceEpoch}',
      );
      if (!context.mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => SheetEditorScreen(sheetId: s.id, sheetName: s.name),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Planillas'),
        actions: [
          IconButton(
            tooltip: 'Nueva',
            onPressed: createSheet,
            icon: const Icon(CupertinoIcons.add),
          ),
        ],
      ),
      body: sheetsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (List<SheetRow> sheets) {
          if (sheets.isEmpty) {
            return const Center(child: Text('No hay planillas aún.'));
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
            itemCount: sheets.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (ctx, i) {
              final s = sheets[i];
              final d = s.createdAt;
              final dd =
                  '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
              return ListTile(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                tileColor: Theme.of(context).colorScheme.surface,
                leading: const Icon(CupertinoIcons.doc_text),
                title: Text(s.name,
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('Creada: $dd • ID: ${s.id}',
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => SheetEditorScreen(
                        sheetId: s.id,
                        sheetName: s.name,
                      ),
                    ),
                  );
                },
                trailing: IconButton(
                  tooltip: 'Eliminar',
                  icon: const Icon(CupertinoIcons.delete_simple),
                  onPressed: () async {
                    await ref.read(sheetsRepoProvider).deleteSheetCascade(s.id);
                  },
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: createSheet,
        icon: const Icon(Icons.add),
        label: const Text('Nueva'),
      ),
    );
  }
}
