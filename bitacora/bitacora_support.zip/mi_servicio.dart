﻿import '../models/measurement.dart';

/// Simula una API de paginaciÃ³n â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
class MiServicio {
  /// Devuelve la â€œsiguiente pÃ¡ginaâ€. Rellena con tu lÃ³gica real.
  static Future<List<Measurement>> fetchNextBatch() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return <Measurement>[]; // â† prÃ³ximos registros
  }
}
