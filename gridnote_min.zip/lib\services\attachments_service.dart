// lib/services/attachments_service.dart
// Utilidades de adjuntos: cámara, galería, ubicación, firma.
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:signature/signature.dart';
import 'package:path_provider/path_provider.dart';

class AttachmentsService {
  AttachmentsService._();
  static final AttachmentsService instance = AttachmentsService._();

  final ImagePicker _picker = ImagePicker();

  /// Cámara → path de archivo o null.
  Future<String?> pickFromCamera() async {
    try {
      final x = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 85,
        preferredCameraDevice: CameraDevice.rear,
      );
      return x?.path;
    } catch (_) {
      return null;
    }
  }

  /// Galería → path de archivo o null.
  Future<String?> pickFromGallery() async {
    try {
      final x = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
      return x?.path;
    } catch (_) {
      return null;
    }
  }

  /// Ubicación actual en formato `geo:lat,lng` o null.
  Future<String?> getCurrentLocation() async {
    try {
      bool service = await Geolocator.isLocationServiceEnabled();
      if (!service) return null;

      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.deniedForever || perm == LocationPermission.denied) {
        return null;
      }

      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 10),
      );
      return 'geo:${p.latitude},${p.longitude}';
    } catch (_) {
      return null;
    }
  }

  /// Abre un `geo:lat,lng` en Maps.
  Future<void> openGeo(String value) async {
    final coords = value.startsWith('geo:') ? value.substring(4) : value;
    final geo = Uri.parse('geo:$coords');
    final gmaps = Uri.parse('https://www.google.com/maps/search/?api=1&query=$coords');

    if (await canLaunchUrl(geo)) {
      await launchUrl(geo, mode: LaunchMode.externalApplication);
      return;
    }
    if (await canLaunchUrl(gmaps)) {
      await launchUrl(gmaps, mode: LaunchMode.externalApplication);
    }
  }

  /// Pide firma en un bottom-sheet. Devuelve path PNG o null.
  Future<String?> addSignature(BuildContext context) async {
    final controller = SignatureController(
      penStrokeWidth: 3,
      penColor: Colors.black,
      exportBackgroundColor: Colors.white,
    );

    String? resultPath;
    await showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            bottom: 16 + MediaQuery.of(ctx).viewInsets.bottom,
            top: 8,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Dibujá tu firma'),
              const SizedBox(height: 8),
              Container(
                height: 220,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.withOpacity(.5)),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Signature(controller: controller, backgroundColor: Colors.white),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  TextButton(
                    onPressed: () => controller.clear(),
                    child: const Text('Limpiar'),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Cancelar'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () async {
                      if (controller.isEmpty) {
                        Navigator.pop(ctx);
                        return;
                      }
                      final bytes = await controller.toPngBytes();
                      if (bytes == null) {
                        Navigator.pop(ctx);
                        return;
                      }
                      final path = await _savePng(bytes);
                      resultPath = path;
                      // ignore: use_build_context_synchronously
                      Navigator.pop(ctx);
                    },
                    child: const Text('Guardar'),
                  ),
                ],
              ),
              const SizedBox(height: 6),
            ],
          ),
        );
      },
    );
    controller.dispose();
    return resultPath;
  }

  Future<String> _savePng(Uint8List bytes) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/firma_${DateTime.now().millisecondsSinceEpoch}.png');
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }
}
