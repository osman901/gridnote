// lib/providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'data/local_db.dart';
import 'repositories/sheets_repository.dart';

final dbProvider = Provider<LocalDB>((_) => LocalDB());
final sheetsRepoProvider =
Provider<SheetsRepository>((ref) => SheetsRepository(ref.read(dbProvider)));

final sheetsProvider = FutureProvider((ref) async {
  final repo = ref.read(sheetsRepoProvider);
  return repo.getSheets();
});

final entriesProvider =
FutureProvider.family.autoDispose((ref, int sheetId) {
  final repo = ref.read(sheetsRepoProvider);
  return repo.rows(sheetId);
});
