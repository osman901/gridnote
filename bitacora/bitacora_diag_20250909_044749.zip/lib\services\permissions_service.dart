import 'package:geolocator/geolocator.dart';

class PermissionsService {
  PermissionsService._();
  static final PermissionsService instance = PermissionsService._();

  /// Pide y verifica el permiso de ubicación. Devuelve `true` si está concedido.
  Future<bool> ensureLocationPermission() async {
    // ¿Servicios de ubicación habilitados?
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return false;

    // Estado actual del permiso
    var perm = await Geolocator.checkPermission();

    // Si está denegado, lo pedimos una vez
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }

    // Denegado para siempre -> abrimos Ajustes y devolvemos false
    if (perm == LocationPermission.deniedForever) {
      await Geolocator.openAppSettings();
      return false;
    }

    // Aceptado
    return perm == LocationPermission.always ||
        perm == LocationPermission.whileInUse;
  }

  /// Compatibilidad con `home_screen.dart`.
  /// Actualmente solo solicita permiso de ubicación.
  Future<void> requestStartupPermissions() async {
    await ensureLocationPermission();
  }
}
