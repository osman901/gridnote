import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';

import '../providers.dart';
import '../services/permissions_service.dart';

class SheetEditorScreen extends ConsumerWidget {
  const SheetEditorScreen({super.key, this.sheetId, this.sheetName});

  final int? sheetId;
  final String? sheetName;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Si no vino un id, mostramos un aviso (evita crashear si se invoca vacío)
    final id = sheetId;
    if (id == null) {
      return Scaffold(
        appBar: AppBar(title: Text(sheetName ?? 'Planilla')),
        body: const Center(
          child: Text('No se especificó una planilla. Volvé atrás.'),
        ),
      );
    }

    final entriesAsync = ref.watch(entriesProvider(id));

    Future<void> _addEmpty() async {
      await ref
          .read(sheetsRepoProvider)
          .addEntry(sheetId: id, title: 'Nueva entrada');
    }

    Future<void> _addWithLocation() async {
      final ok = await PermissionsService.instance.ensureLocationPermission();
      if (!ok) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Sin permiso de ubicación. Revisá Ajustes.'),
            ),
          );
        }
        return;
      }

      final pos = await Geolocator.getCurrentPosition();
      await ref.read(sheetsRepoProvider).addEntry(
        sheetId: id,
        title: 'Entrada con ubicación',
        lat: pos.latitude,
        lng: pos.longitude,
        accuracy: pos.accuracy,
        provider: pos.heading == 0 ? 'gps' : 'sensor',
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(sheetName ?? 'Planilla'),
        actions: [
          IconButton(
            tooltip: 'Agregar con ubicación',
            onPressed: _addWithLocation,
            icon: const Icon(Icons.near_me_outlined),
          ),
        ],
      ),
      body: entriesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (entries) {
          if (entries.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.description_outlined, size: 40),
                  const SizedBox(height: 8),
                  const Text('Sin entradas aún'),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: _addEmpty,
                    child: const Text('Crear primera entrada'),
                  ),
                ],
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
            itemCount: entries.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final e = entries[i];
              return ListTile(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                tileColor: Theme.of(context).colorScheme.surface,
                title: Text(e.title ?? '(sin título)'),
                subtitle: Text(e.note ?? ''),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addEmpty,
        icon: const Icon(Icons.add),
        label: const Text('Nueva'),
      ),
    );
  }
}
