class Sheet {
  final int? id;
  final String name;
  final DateTime createdAt;

  Sheet({this.id, required this.name, required this.createdAt});

  Sheet copyWith({int? id, String? name, DateTime? createdAt}) => Sheet(
      id: id ?? this.id, name: name ?? this.name, createdAt: createdAt ?? this.createdAt);

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'created_at': createdAt.millisecondsSinceEpoch,
  };

  static Sheet fromMap(Map<String, dynamic> m) => Sheet(
    id: m['id'] as int,
    name: m['name'] as String,
    createdAt: DateTime.fromMillisecondsSinceEpoch(m['created_at'] as int),
  );
}

class Entry {
  final int? id;
  final int sheetId;
  final String? note;
  final double? lat;
  final double? lon;
  final String? photoPath; // ruta interna

  Entry({
    this.id,
    required this.sheetId,
    this.note,
    this.lat,
    this.lon,
    this.photoPath,
  });

  Entry copyWith({
    int? id, int? sheetId, String? note, double? lat, double? lon, String? photoPath,
  }) => Entry(
    id: id ?? this.id,
    sheetId: sheetId ?? this.sheetId,
    note: note ?? this.note,
    lat: lat ?? this.lat,
    lon: lon ?? this.lon,
    photoPath: photoPath ?? this.photoPath,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'sheet_id': sheetId,
    'note': note,
    'lat': lat,
    'lon': lon,
    'photo_path': photoPath,
  };

  static Entry fromMap(Map<String, dynamic> m) => Entry(
    id: m['id'] as int,
    sheetId: m['sheet_id'] as int,
    note: m['note'] as String?,
    lat: (m['lat'] as num?)?.toDouble(),
    lon: (m['lon'] as num?)?.toDouble(),
    photoPath: m['photo_path'] as String?,
  );
}
