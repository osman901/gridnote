// lib/screens/sign_in_screen.dart
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../theme/gridnote_theme.dart';

/// ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸ÃƒÂ¢Ã¢â€šÂ¬Ã‹Å“ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â° EditÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ esta lista con los correos habilitados para usar la app.
/// PodÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s reemplazarlo luego por Remote Config / .env si querÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s.
const List<String> kAllowedEmails = <String>[
  // 'empleado1@tuempresa.com',
  // 'empleado2@tuempresa.com',
];

class SignInScreen extends StatelessWidget {
  const SignInScreen({super.key, required this.theme});
  final GridnoteThemeController theme;

  @override
  Widget build(BuildContext context) {
    final t = theme.theme;

    return Scaffold(
      backgroundColor: t.scaffold,
      body: Center(
        child: FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: t.accent,
            foregroundColor: Colors.black,
          ),
          onPressed: () async {
            // Evitamos usar `context` despuÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©s de awaits
            final messenger = ScaffoldMessenger.of(context);
            try {
              // ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã¢â‚¬Å“ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ Pasamos la lista de correos permitidos (API actual de AuthService)
              await AuthService.signInWithGoogle(kAllowedEmails);

              // (Opcional) Feedback de ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©xito
              // messenger.showSnackBar(
              //   const SnackBar(content: Text('Inicio de sesiÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³n correcto')),
              // );
            } catch (e) {
              messenger.showSnackBar(
                SnackBar(content: Text('Error: $e')),
              );
            }
          },
          icon: const Icon(Icons.login),
          label: const Text('Ingresar con Google'),
        ),
      ),
    );
  }
}
